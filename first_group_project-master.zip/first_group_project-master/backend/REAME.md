# hungry students back-end

Here will be the code and logic that will expose the data in the database for the front end

## Set up

To set up this project for development you need to create a virtual environment. Run the following commands ($ is the prompt)

from the ".../backend" directory
```bash
$ python3 -m venv venv
$ . venv/bin/activate
$ pip install -r requirements.txt
```

You will need to set up the configuration files for the database, including your username and password for the mysql server.

Go to [web.cs.manchester.ac.uk](http://web.cs.manchester.ac.uk/) and set a username and password for the database. **Do not use your my.manchester password**

Copy the file `config.sample.json` to `config.json` and edit the `<USERNAME>` and `<PASSWORD>` to reflect your actual password

**When making commits, do NOT add `config.json`, as this contains your password**

## Running the webserver

Make sure you have created your venv and it is activated. You should see the word "(venv)" in your shell prompt if this is the case. If not, you can activate the venv by doing the following:

```bash
$ . venv/bin/activate
```

Once you have activated the venv, you can start the webserver: 

```bash
$ python3 src/__main__.py
```

By default this should start the on [localhost:8080](http://localhost:8080)

Make sure you restart the server if you make any changes to the code.

You can use a tool like [curl](https://curl.se/) or [Postman](https://www.postman.com/) to test the API endpoints or use the front-end implementations once they are completed.

