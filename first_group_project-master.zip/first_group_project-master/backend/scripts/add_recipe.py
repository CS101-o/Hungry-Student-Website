#!/usr/bin/env python3
import mysql.connector
import json
import os

config = {}
with open("config.json", "r") as file:
    config = json.load(file)

mydb = mysql.connector.connect(
        host=config["host"],
        user=config["username"],
        password=config["password"],
        database=config["database"]
    )

mycursor = mydb.cursor()

#mycursor.execute("""CREATE TABLE Recipe (
#                    recipeID INT AUTO_INCREMENT PRIMARY KEY,
#                    name VARCHAR(255), 
#                    budget INT(255),
#                    difficulty INT(255), 
#                    time INT(255));""")
#mycursor.execute("""CREATE TABLE Ingredient (
#                        ingredientID INT AUTO_INCREMENT PRIMARY KEY,
#                        name VARCHAR(255),
#                        vegan BOOL, 
#                        allergens BOOL,
#                        vegetarian BOOL);""")
#mycursor.execute("""CREATE TABLE RecipeIngredient (
#                            recipeID INT(255),
#                            ingredientID INT(255),
#                            quantity DECIMAL,
#                            unit VARCHAR(255),
#                            PRIMARY KEY (recipeID, ingredientID)
#                            );""")

name = input("What is the recipe name: ")
budget = int(input("What is the budget 1-3: "))
difficulty = int(input("What is the difficulty 1-3: "))
time = input("What is the time in minutes?: ")


ingredients = []

add = input("Add ingredient? yes/no")
while "y" in add.lower():
    ingredient_name = input("What is the name of this ingredient: ")
    vegan = not "n" in input("Is it vegan? {Y/n}").lower()
    alergens = not "n" in input("Are there allergens? {Y/n}").lower()
    vegetarian = not "n" in input("Is it vegetarian? {Y/n}").lower()

    quantity = float(input("Enter numeric quantity: "))
    unit = input("Enter quantity unit: ")

    ingredients.append(
            {
                "name": ingredient_name,
                "vegan": vegan,
                "allergens": alergens,
                "vegetarian": vegetarian,
                "quantity": quantity,
                "unit": unit,
                })

    add = input("Add another ingredient? yes/no")

print("Enter the method for this recipe, leaving an empty line to finish:")
lines = []
line = input()
lines.append(line)
while line:
    line = input()
    lines.append(line)

mycursor.execute("INSERT INTO Recipe (name, budget, difficulty, time) VALUES (%s, %s, %s, %s)", (name, budget, difficulty, time))
mydb.commit()
rID = mycursor.lastrowid

for ingredient in ingredients:
    mycursor.execute("SELECT IngredientID FROM Ingredient WHERE name = %s", (ingredient["name"], ))
    myresult = mycursor.fetchall() 
    if not myresult:
        mycursor.execute("INSERT INTO Ingredient (name, vegan, allergens, vegetarian) VALUES (%s, %s, %s, %s)", (
            ingredient["name"], 
            ingredient.get("vegan", False),
            ingredient["allergens"],
            ingredient["vegetarian"],
                        )
             )
        mydb.commit()
        iID = mycursor.lastrowid
    else:
        iID = myresult[0][0]
    
    print(f"Ingredient id is {iID}")

    mycursor.execute("INSERT INTO RecipeIngredient (recipeID, ingredientID, quantity, unit) VALUES (%s, %s, %s, %s)", (
        int(rID), 
        int(iID), 
        ingredient["quantity"],
        ingredient["unit"],
         )
                     )
    mydb.commit()

    path = os.path.join(config.get("filestore", "data"), "recipes", f"{rID}.txt")
    with open(path, "w") as file:
        for line in lines:
            file.write(line + "\n")
