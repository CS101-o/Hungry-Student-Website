#!/usr/bin/env python3
import os
import json

from http.server import HTTPServer
from optparse import OptionParser
from glob import glob

from config import load_config
from endpoint import *
import database

MODULES_DIR = "modules"

# when this is called as the main program
if __name__ == "__main__":
    print("Starting hungry students backend")

    hostname = "0.0.0.0"
    serverPort = 8080

    # parse command line arguments as options
    parser = OptionParser()
    parser.add_option("-p", "--port", dest="port", default=8080)
    parser.add_option("-n", "--hostname", dest="hostname", default="0.0.0.0")
    
    (options, args) = parser.parse_args()

    # Load the config file
    config = load_config()
    print(f"Using config parameters: {config}")

    # initialise the connection to the database
    database.init_database(config)

    # create a new webserver instance
    serv = HTTPServer((options.hostname, options.port), EndpointHTTPRequestHandler)

    # look through all the python files in a directory
    for file in glob(os.path.join(os.path.dirname(os.path.abspath(__file__)), MODULES_DIR, "*.py")):
        # import this python file as a module
        name = os.path.splitext(os.path.basename(file))[0]
        module = __import__(f"{MODULES_DIR}.{name}")
        # since we are using decorators these should automatically register to the handler

    print(f"Server started on http://{options.hostname}:{options.port}/")

    # run the web server until we cancel it 
    try:
        serv.serve_forever()
    except KeyboardInterrupt:
        pass

    serv.server_close()
    print("Server stopped!")

