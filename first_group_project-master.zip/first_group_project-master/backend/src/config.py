import json
import os

CONFIG_FILE = "config.json"
configuration = {}

def load_config():
    global configuration

    # if the config has already been loaded, do not load it again
    if configuration:
        return configuration
    
    # load the config from json file
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as file:
            configuration = json.load(file)

        return configuration
    else:
        raise Exception(f"No config file found in {CONFIG_FILE}")

def get(key, default):
    return load_config().get(key, default)


