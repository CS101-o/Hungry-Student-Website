import json
import re
import traceback

from fnmatch import fnmatch
from sys import stderr
from http.server import BaseHTTPRequestHandler

get_methods = {}
post_methods = {}
delete_methods = {}
put_methods = {}

ERROR_JSON = json.dumps({
        "message": "An error occured"
        })

UNKNOWN_JSON = json.dumps({
        "message": "This page could not be found"
        })

def get_method(route):
    def route_encloser(func):
        get_methods[route] = func
        def executor(*args,**kwargs):
            return func(*args,**kwargs)
        return executor

    return route_encloser

def post_method(route):
    def route_encloser(func):
        post_methods[route] = func
        def executor(*args,**kwargs):
            return func(*args,**kwargs)
        return executor

    return route_encloser

def put_method(route):
    def route_encloser(func):
        put_methods[route] = func
        def executor(*args,**kwargs):
            return func(*args,**kwargs)
        return executor

    return route_encloser

def delete_method(route):
    def route_encloser(func):
        delete_methods[route] = func
        def executor(*args,**kwargs):
            return func(*args,**kwargs)
        return executor

    return route_encloser

class EndpointHTTPRequestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.do_method(get_methods)

    def do_POST(self):
        self.do_method(post_methods)

    def do_PUT(self):
        self.do_method(put_methods)

    def do_DELETE(self):
        self.do_method(delete_methods)

    def do_OPTIONS(self):
        self.send_json(200, {"message": "This is a placeholder response to allow CORS requests"})


    def do_method(self, methods):
        # check which endpoints have the requested path
        for endpoint_path, endpoint_function in methods.items():

            # match this path with the endpoint
            if fnmatch(self.path, endpoint_path):
                try:
                    # extract the request body
                    content_len = self.headers.get('Content-Length')
                    if content_len:
                        body_content = self.rfile.read(int(content_len))

                        # if the body is not json then make a json object from it
                        try:     
                            body = json.loads(body_content)   
                        except ValueError as e:     
                            body = {
                                    "request" : body_content
                                    }
                    else:
                        body = {}

                    response = endpoint_function(self.path, body, self.headers)
                    if type(response) is dict:
                        code = response.get("code", 200)
                    else:
                        code = 200

                    # send a 200 code if no other is specified
                    self.send_json(code, response)

                except Exception as e:
                    # print the exception so we can figure out what went wrong
                    traceback.print_exception(e)
                    self.send_json(500, ERROR_JSON)
                return

        # if no endpoints at this path were found send a 404
        self.send_json(404, UNKNOWN_JSON)

    def send_my_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")

    def send_json(self, code, json_object):
        # encode the response as a json if it is not already
        if type(json_object) is dict:
            response = json.dumps(json_object)
        else:
            response = json.dumps({
                    "response" : json_object
                    })

        self.send_response(code)
        self.send_header("Content-type", "text/json")
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Headers', '*')
        self.send_header('Access-Control-Allow-Credentials', 'true')
        self.end_headers()

        self.wfile.write(bytes(response + "\n", "utf-8"))

