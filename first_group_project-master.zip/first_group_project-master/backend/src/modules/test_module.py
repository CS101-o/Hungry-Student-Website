from endpoint import *
# This is a "module" file which will be read by the server on load
# place functions with the method decorators on them in files in this directory

# these are all test methods that don't do anything, to be removed

# add an endpoint to /hello that will return Hello World
@get_method("/hello")
def get_hello(path, body, headers):
    return "Hello World"

# return a dictionary as a json object
@get_method("/test")
def get_test(path, body, headers):
    return {
            "test": "This is a test",
            "number": 12
            }

# a test post request that will return the body
@post_method("/echo")
def post_echo(path, body, headers):
    return body

# wildcards work in the url
@get_method("/other/*")
def post_echo(path, body, headers):
    return f"you requested {path}"


