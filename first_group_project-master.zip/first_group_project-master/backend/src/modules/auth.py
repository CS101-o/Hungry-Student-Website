from endpoint import *
from database import mydb
import string
import random
TOKEN_LENGTH = 256

tokens = {}

def check_headers(headers):
    if "Authorization" in headers:
        token = headers.get("Authorization")
        return get_id(token)
    return ""

def make_user_table(cursor):
    cursor.execute("""CREATE TABLE IF NOT EXISTS User ( 
                    userID INT AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(255),
                    email VARCHAR(255),
                    password VARCHAR(255)
                   )""")


def register_token(userID):
    global tokens
    token = ''.join(random.choice(string.ascii_letters)
                    for _ in range(TOKEN_LENGTH))
    tokens[token] = userID
    return token

def get_id(token):
    if token in tokens:
        return tokens[token]
    return ""


@post_method("/auth/register")
def register_user(path, body, header):
    username = body.get("username", "")
    email = body.get("email", "")
    password = body.get("password", "")
    if not email:
        return {"code": 400, "message": "Please enter an email"}

    if not username:
        return {"code": 400, "message": "Please enter a username"}

    if not password:
        return {"code": 400, "message": "Please enter a password"}

    mycursor = mydb.cursor()
    make_user_table(mycursor)

    # check if user exists already
    mycursor.execute( "SELECT username FROM User WHERE username = %s", (username,))
    if mycursor.fetchall():
        return {"code": 400, "message": "This username is taken"}

    mycursor.execute( "SELECT username FROM User WHERE email = %s", (email,))
    if mycursor.fetchall():
        return {"code": 400, "message": "This email is taken"}

    mycursor.execute(
        "INSERT INTO User (username, email, password) VALUES (%s, %s, %s)", (username, email, password))
    mydb.commit()
    userid = mycursor.lastrowid
    return {"code": 200, "message": "success", "id": userid}


@post_method("/auth/login")
def login_user(path, body, header):
    email = body.get("email", "")
    password = body.get("password", "")
    if not email:
        return {"code": 400, "message": "Please enter an email"}

    if not password:
        return {"code": 400, "message": "Please enter a password"}

    mycursor = mydb.cursor()
    make_user_table(mycursor)

    mycursor.execute(
        "SELECT userID, username, email, password FROM User WHERE email = %s AND password = %s", (email, password))

    results = mycursor.fetchall()
    if not results:
        return {"code": 400, "message": "Invalid email or password"}

    userid, username, email, password = results[0]
    token = register_token(userid)

    return {"code": 200, "message": "success", "id": userid, "token": token}

@get_method("/auth/info")
def user_info(path, body,headers):
    userid = check_headers(headers)
    if not userid:
        return {"code": 200, "message": "Invalid token"}

    mycursor = mydb.cursor()
    mycursor.execute(
        "SELECT userID, username, email, password FROM User WHERE userID = %s", (userid,))
    
    results = mycursor.fetchall()
    if not results:
        return {"code": 500, "message": "Invalid token"}

    userid, username, email, password = results[0]
    return {
            "id": userid,
            "username": username,
            "email": email,
            "password": password
            }


