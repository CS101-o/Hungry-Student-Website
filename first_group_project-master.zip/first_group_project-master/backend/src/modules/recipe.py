import os

from endpoint import *
import database
import config
from urllib.parse import urlparse
from urllib.parse import parse_qs

import base64


@get_method("/ingredient/list")
def list_ingredients(path, body, headers):
    res = database.database_list_ingredients()
    ingredients = [
        {
            "id": row[1],
            "name": row[0],
        } for row in res
    ]
    return {"ingredients": ingredients}


@get_method("/recipe/info/*")
def get_recipe_info(path, body, headers):
    recipe_id = path[len("/recipe/info/"):]
    if recipe_id == -1:
        return {
            "message": "No recipe ID was specified",
            "code": 400
        }

    result = database.database_recipe_info(recipe_id)
    recipeinfo = []
    for row in result:
        recipeinfo.append({"id": row[3],
                           "name": row[2],
                           "quantity": float(row[4]),
                           "unit": row[5]})

    return {"id": result[0][1], "name": result[0][0], "ingredients": recipeinfo, "time": result[0][6], "difficulty": result[0][7], "budget": result[0][8]}


@get_method("/recipe/list*")
def list_recipes(path, body, headers):
    parsed_url = urlparse(path)
    query = parse_qs(parsed_url.query)

    ingredients = query.get("ingredients[]", [])

    difficulty = query.get("difficulty", [0])[0]
    time = query.get("time", [0])[0]
    budget = query.get("budget", [0])[0]

    vegan = query.get("vegan", ["false"])[0] == "true"
    vegetarian = query.get("vegetarian", ["false"])[0] == "true"
    allergens = query.get("allergens", ["false"])[0] == "true"

    # TODO: don't pass quite as many args
    result = database.database_list_recipes(ingredients,
                                            time=time,
                                            budget=budget,
                                            difficulty=difficulty,
                                            vegan=vegan,
                                            vegetarian=vegetarian,
                                            allergens=allergens
                                            )
    recipes = [
        {
            "id": row[0],
            "name": row[1],
            "difficulty": row[2],
            "time": row[3],
            "budget": row[4],
        } for row in result
    ]

    return {"recipes": recipes}


@get_method("/recipe/body/*")
def get_recipe_body(path, body, headers):
    recipe_id = path[len("/recipe/body/"):]
    if recipe_id == -1:
        return {
            "message": "No recipe ID was specified",
            "code": 400
        }

    path = os.path.join(config.get("filestore", "data"),
                        "recipes", f"{recipe_id}.txt")
    if os.path.exists(path):
        with open(path, "r") as file:
            data = [line.strip() for line in file.readlines()]
            return {
                "steps": data
            }
    return {
        "message": f"No recipe body was found for id {recipe_id}",
        "code": 404
    }


@get_method("/recipe/image/*")
def get_recipe_image(path, body, headers):
    recipe_id = path[len("/recipe/image/"):]
    if recipe_id == -1:
        return {
            "message": "No recipe ID was specified",
            "code": 400
        }

    path = os.path.join(config.get("filestore", "data"),
                        "images", f"{recipe_id}.jpg")
    if os.path.exists(path):
        with open(path, "rb") as file:
            data = file.read()
            data_base64 = base64.b64encode(data)
            data_base64 = data_base64.decode('ascii')

            return {
                "image": "data:image/jpeg;base64," + data_base64
            }
    return {
        "message": f"No recipe image was found for id {recipe_id}",
        "code": 404
    }

@post_method("/ingredient/add")
def add_ingredient(path, body, headers):
    # TODO add authorization to this endpoint
    id = database.database_add_ingredient(body["ingredient"])
    return {
            "id": id
            }

@post_method("/recipe/add")
def add_recipe(path, body, headers):
    # TODO add authorization to this endpoint
    id = database.database_add_recipe(body["recipe"])
    print(f"added recipe {id} with name {body['recipe']['name']}")
    
    path = os.path.join(config.get("filestore", "data"),
                        "images", f"{id}.jpg")
    if "image" in body["recipe"]:
        with open(path, "wb") as file:
            data = base64.b64decode(body["recipe"]["image"][len("data:image/jpeg;base64,"):])
            file.write(data)
        
    return {
            "id": id
            }


