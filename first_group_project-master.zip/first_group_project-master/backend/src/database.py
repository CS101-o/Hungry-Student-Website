#!/usr/bin/env python3
import mysql.connector
import json
import config
import os

SQL_NO_INGREDIENTS_EXIST = """NOT EXISTS (
            SELECT Ingredient.ingredientID FROM Ingredient, RecipeIngredient 
            WHERE RecipeIngredient.recipeID = Recipe.recipeID AND Ingredient.ingredientID = RecipeIngredient.ingredientID 
            AND NOT {}
            );"""

def make_tables(mycursor):
    mycursor.execute("""CREATE TABLE IF NOT EXISTS Recipe (
                        recipeID INT AUTO_INCREMENT PRIMARY KEY,
                        name VARCHAR(255), 
                        budget INT(255),
                        difficulty INT(255), 
                        time INT(255));""")
    mycursor.execute("""CREATE TABLE IF NOT EXISTS Ingredient (
                            ingredientID INT AUTO_INCREMENT PRIMARY KEY,
                            name VARCHAR(255),
                            vegan BOOL, 
                            allergens BOOL,
                            vegetarian BOOL);""")
    mycursor.execute("""CREATE TABLE IF NOT EXISTS RecipeIngredient (
                                recipeID INT(255),
                                ingredientID INT(255),
                                quantity DECIMAL,
                                unit VARCHAR(255),
                                PRIMARY KEY (recipeID, ingredientID)
                                );""")


def execute_sql(sql, *args):
    mycursor = mydb.cursor()
    mycursor.execute(sql, args)
    mycursor.commit()
    return mycursor


def database_recipe_info(recipeID):
    make_tables(mydb.cursor())
    mycursor = mydb.cursor()
    sql = "SELECT Recipe.name, Recipe.recipeID, Ingredient.name, Ingredient.ingredientID, RecipeIngredient.quantity, RecipeIngredient.unit,Recipe.time,Recipe.difficulty,Recipe.budget from Recipe, RecipeIngredient, Ingredient"
    where = []
    val = []

    # link recipe ingredients with recipe
    where.append("Recipe.recipeID = RecipeIngredient.recipeID")
    where.append("Ingredient.ingredientID = RecipeIngredient.ingredientID")
    where.append("Recipe.recipeID = %s")
    val.append(recipeID)
    sql = sql + " WHERE " + " AND ".join(where)
    mycursor.execute(sql, val)
    return mycursor.fetchall()


def database_list_ingredients():
    make_tables(mydb.cursor())
    mycursor = mydb.cursor()
    sql = "SELECT Ingredient.name, Ingredient.ingredientID FROM `Ingredient`;"
    mycursor.execute(sql)

    myresult = mycursor.fetchall()
    return myresult


def database_list_recipes(ingredients, difficulty=0, time=0, budget=0, vegan=False, vegetarian=False, allergens=False):
    make_tables(mydb.cursor())
    mycursor = mydb.cursor()

    # build an SQL query that will find recipes matching certain requirements
    sql = "SELECT DISTINCT Recipe.recipeID,Recipe.name,Recipe.difficulty,Recipe.time,Recipe.budget FROM Recipe, RecipeIngredient, Ingredient"

    val = []
    where = []

    # link recipe ingredients with recipe
    where.append("Recipe.recipeID = RecipeIngredient.recipeID")
    where.append("Ingredient.ingredientID = RecipeIngredient.ingredientID")

    ingredients_sql = []
    for ingredient in ingredients:
        ingredients_sql.append("RecipeIngredient.ingredientID = %s")
        val.append(ingredient)

    #
    if ingredients:
        where.append("(" + " OR ".join(ingredients_sql) + ")")

    if difficulty:
        where.append("Recipe.difficulty = %s")
        val.append(difficulty)

    if time:
        where.append("Recipe.time = %s")
        val.append(time)

    if budget:
        where.append("Recipe.budget = %s")
        val.append(budget)

    if vegetarian:
        # check that no ingredients that arent vegetarian exist given recipes
        where.append(SQL_NO_INGREDIENTS_EXIST.format("Ingredient.vegetarian"))

    if vegan:
        # check that no ingredients that arent vegan exist in the given recipes
        where.append(SQL_NO_INGREDIENTS_EXIST.format("Ingredient.vegan"))

    if allergens:
        # check that no ingredients that arent allergens exist in the given recipes
        where.append(SQL_NO_INGREDIENTS_EXIST.format(
            "NOT Ingredient.allergens"))

    sql = sql + " WHERE " + " AND ".join(where)

    mycursor.execute(sql, val)
    return mycursor.fetchall()


def database_add_ingredient(ingredient):
    make_tables(mydb.cursor())
    mycursor = mydb.cursor()
    mycursor.execute("INSERT INTO Ingredient (name, vegan, allergens, vegetarian) VALUES (%s, %s, %s, %s)", (
        ingredient["name"],
        ingredient.get("vegan", False),
        ingredient.get("allergens", False),
        ingredient.get("vegetarian", False),
    )
    )
    mydb.commit()
    return mycursor.lastrowid

def database_add_recipe(recipe):
    make_tables(mydb.cursor())
    mycursor = mydb.cursor()

    mycursor.execute("INSERT INTO Recipe (name, budget, difficulty, time) VALUES (%s, %s, %s, %s)", (
        recipe["name"], recipe["budget"], recipe["difficulty"], recipe["time"]
    ))
    mydb.commit()
    recipeId = mycursor.lastrowid

    ingredients = recipe["ingredients"]
    for ingredient in ingredients:
        mycursor.execute("INSERT INTO RecipeIngredient (recipeID, ingredientID, quantity, unit) VALUES (%s, %s, %s, %s)", (
            int(recipeId), 
            int(ingredient["id"]), 
            ingredient["quantity"],
            ingredient["unit"],
        )
        )
    mydb.commit()

    path = os.path.join(config.get("filestore", "data"), "recipes", f"{recipeId}.txt")
    with open(path, "w") as file:
        for line in recipe["steps"]:
            file.write(line + "\n")
    return recipeId


def init_database(config):
    global mydb
    # TODO: avoid using global here
    mydb = mysql.connector.connect(
        host=config["host"],
        user=config["username"],
        password=config["password"],
        database=config["database"]
    )
    return mydb
