#!/bin/sh

registry=hungrystudents.azurecr.io
projects="frontend backend proxy mysql"
[ ! -z "$*" ] && projects="$*"


for proj in $projects; do
    [ "$proj" = "mysql" ] && {
        docker image pull mysql:5.7
        docker image tag mysql:5.7 $registry/hungrystudents/mysql:5.7
        docker push $registry/hungrystudents/mysql:5.7
    } || {
        docker build -t $registry/hungrystudents/$proj:latest $proj
        docker push $registry/hungrystudents/$proj:latest
    }
done

