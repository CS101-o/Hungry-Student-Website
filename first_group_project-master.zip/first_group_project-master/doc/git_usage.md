# Using git

## Adding a new feature

### Creating a branch
When working on a new feature, it is sensible to do all of your work on a new branch.

Create a new branch while checked-out on master with a descriptive name. Also include your name so that it is clear who is working on which branch. For example if you are adding a "recipe feature" you may do the following:

```sh
git checkout master # ensure that you are on the master branch

git checkout -b JohnD_RecipeFeature # create a new branch
```

Now you are free to make any changes that you'd like without disturbing anything in master.

### Working on your feature

Regularly make commits to your branch and push your work to ensure that everything is backed up:

```sh
git add newFile.py # add any new files explicitly, avoiding adding anything that doesnt need to be tracked
git commit -a -m "Add new files with cool new features" # create a commit

git push # push to your branch 
```

(you may need to specify the branch and remote the first time you push to your new branch, however git should prompt you with the correct command that will let you do this)

To save time with resolving conflicts later on, regularly pull from the master branch, to get any new changes.

While checked out on your new branch:
```sh
git pull # pull all new changes from the remote
git rebase master # stack all these changes ontop
```

you may now need to resolve any conflicts that arrise. When these are resolved, make sure to commit the changes, then `git rebase --continue` to continue with the rebase. Don't forget to `git push` after you are finished.

### Finishing your feature

Once you are finished with implementing your feature and you are satisfied that everything works, you are ready to push back into master. 

From your branch
```sh
git pull # pull all new changes in the remote
git rebase master
```

Now resolve any conflicts that might arrise.
This is the point where you might want to ask other members of the group to review your code, that way they can ensure that there are no mistakes or changes that might affect their own.
Once you've confirmed with everyone, then it is time to push back into master. Make sure that the last step has been fully resolved so that you don't get any conflicts in master:

```sh
git checkout master 
git rebase JohnD_RecipeFeature
git push
```

If all has gone well, your changes should all be reflected in the master branch and ready for everyone to see. At this point, you might want to inform that your changes are now in master and that everyone should rebase master from their branches to get these new changes.
